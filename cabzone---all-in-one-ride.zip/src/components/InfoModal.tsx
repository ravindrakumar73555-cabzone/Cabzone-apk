import React from 'react';
import { ShieldCheck, MapPin, ExternalLink, Zap, Check, Smartphone } from 'lucide-react';

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in">
      <div className="w-full max-w-sm bg-[#0b1220] border border-[#10ef70]/40 rounded-2xl p-4 shadow-2xl space-y-3.5 text-slate-200">
        <div className="flex items-center justify-between pb-2 border-b border-white/10">
          <div className="flex items-center gap-2">
            <span className="text-[#10ef70] font-black text-base">CABZONE</span>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">Prototype Guide</span>
          </div>
          <button
            onClick={onClose}
            className="w-6 h-6 rounded-full bg-white/10 text-slate-300 hover:text-white flex items-center justify-center text-xs"
          >
            ✕
          </button>
        </div>

        <div className="space-y-2.5 text-xs">
          <div className="flex items-start gap-2">
            <span className="text-base">🗺️</span>
            <div>
              <strong className="text-white block">Top 40% Live Map:</strong>
              Shows moving ONDC driver dots with active headings. Tap any dot to view driver card or connect.
            </div>
          </div>

          <div className="flex items-start gap-2">
            <span className="text-base">📍</span>
            <div>
              <strong className="text-white block">Middle Search Bars:</strong>
              Interactive Pickup & Drop destination inputs with quick-pills (Airport, Tech Park, Metro). Automatically recalibrates distance and fares.
            </div>
          </div>

          <div className="flex items-start gap-2">
            <span className="text-base">📊</span>
            <div>
              <strong className="text-white block">Bottom 60% Comparison:</strong>
              Compares ONDC zero-commission direct rides side-by-side with Uber, Ola, and InDrive fares and ETAs.
            </div>
          </div>

          <div className="flex items-start gap-2">
            <span className="text-base">📱</span>
            <div>
              <strong className="text-white block">In-App WebViews:</strong>
              Tapping Uber, Ola, or InDrive opens an authentic simulated Android In-App WebView with address bar and native web-booking actions.
            </div>
          </div>

          <div className="flex items-start gap-2">
            <span className="text-base">🟢</span>
            <div>
              <strong className="text-white block">Direct ONDC Booking:</strong>
              Simulates broadcast, driver assignment, vehicle number plate, start OTP, and direct UPI QR / Cash payment.
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-[#10ef70] hover:bg-[#00e676] text-[#070b14] font-bold rounded-xl text-xs shadow-md transition-all active:scale-95"
        >
          Got It, Start Exploring
        </button>
      </div>
    </div>
  );
};
