import React, { useState } from 'react';
import { 
  ShieldCheck, 
  ExternalLink, 
  Clock, 
  ArrowRight,
  TrendingDown,
  Info,
  Sparkles
} from 'lucide-react';
import { RideOption, RideProvider, LanguageCode } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface RideListProps {
  rides: RideOption[];
  language: LanguageCode;
  onBookDirectONDC: (ride: RideOption) => void;
  onOpenWebView: (provider: RideProvider, ride: RideOption) => void;
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
}

export const RideList: React.FC<RideListProps> = ({
  rides,
  language,
  onBookDirectONDC,
  onOpenWebView,
  selectedCategory,
  onCategoryChange,
}) => {
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;
  const [activeFilter, setActiveFilter] = useState<string>(selectedCategory || 'ALL');

  const categories = [
    { id: 'ALL', label: t.allRides },
    { id: 'ONDC', label: t.ondcDirect },
    { id: 'LOWEST', label: t.lowestFare },
    { id: 'FASTEST', label: t.fastestEta },
    { id: 'AUTO', label: t.autos },
    { id: 'CAB', label: t.cabs },
  ];

  const handleFilterClick = (id: string) => {
    setActiveFilter(id);
    onCategoryChange(id);
  };

  // Filter rides based on chosen tab
  const filteredRides = [...rides].filter((ride) => {
    if (activeFilter === 'ONDC') return ride.isDirectONDC;
    if (activeFilter === 'AUTO') return ride.vehicleType === 'AUTO';
    if (activeFilter === 'CAB') return ride.vehicleType !== 'AUTO' && ride.vehicleType !== 'BIKE';
    return true;
  });

  // Default sort is CHEAPEST FIRST unless FASTEST is chosen
  if (activeFilter === 'FASTEST') {
    filteredRides.sort((a, b) => a.etaMinutes - b.etaMinutes);
  } else {
    // Sort cheapest first by default
    filteredRides.sort((a, b) => a.calculatedFare - b.calculatedFare);
  }

  // Find lowest price overall to mark as cheapest
  const minPrice = Math.min(...rides.map(r => r.calculatedFare));

  return (
    <div id="cabzone-rides-section" className="rides-section flex-1 overflow-y-auto p-3.5 bg-[#0b1120] flex flex-col">
      {/* Category Filter Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-2.5 shrink-0">
        {categories.map((cat) => {
          const isActive = activeFilter === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => handleFilterClick(cat.id)}
              className={`px-2.5 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap transition-all ${
                isActive
                  ? 'bg-[#a3e635] text-[#0b1120] shadow-[0_0_10px_rgba(163,230,53,0.3)] font-bold'
                  : 'bg-[#1e293b] text-[#94a3b8] border border-[#334155] hover:text-white'
              }`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* Section Title matching user specification */}
      <div className="section-title text-xs text-[#94a3b8] mb-2 flex justify-between items-center px-0.5">
        <span className="font-bold uppercase tracking-wider text-slate-300">
          {t.ridesTitle}
        </span>
        <span className="text-[10px] text-[#a3e635] font-semibold">
          ⚡ {filteredRides.length} Available
        </span>
      </div>

      {/* Ride Comparison List */}
      <div className="ride-list flex flex-col gap-2.5 pb-20">
        {filteredRides.map((ride, idx) => {
          const isCheapest = ride.calculatedFare === minPrice;
          const isONDC = ride.isDirectONDC;

          return (
            <div
              key={ride.id}
              id={`ride-card-${ride.id}`}
              className={`ride-card bg-[#1e293b] rounded-xl p-3 flex justify-between items-center border transition-all ${
                isCheapest 
                  ? 'cheapest border-[#a3e635] shadow-[0_0_15px_rgba(163,230,53,0.12)] relative' 
                  : 'border-[#334155] hover:border-[#475569]'
              }`}
            >
              {/* CHEAPEST TAG from user specification */}
              {isCheapest && (
                <div className="cheapest-tag absolute -top-2.5 right-4 bg-[#a3e635] text-[#0b1120] text-[9px] font-black px-2 py-0.5 rounded-full uppercase tracking-wider shadow-md">
                  {t.cheapest}
                </div>
              )}

              {/* Ride Info (Left) */}
              <div className="ride-info flex-1 pr-2 min-w-0">
                <h3 className="m-0 text-sm font-bold text-white flex items-center gap-1.5 flex-wrap">
                  <span>{ride.name}</span>
                  
                  {/* Company Tag */}
                  <span className={`company-type text-[9px] font-bold px-1.5 py-0.5 rounded ${
                    isONDC ? 'ondc-type bg-[#047857] text-[#a7f3d0]' : 'bg-[#475569] text-[#cbd5e1]'
                  }`}>
                    {isONDC ? 'ONDC DIRECT' : ride.provider}
                  </span>

                  {ride.badge && !isCheapest && (
                    <span className="text-[8px] bg-[#334155] text-amber-300 px-1 py-0.2 rounded font-semibold">
                      {ride.badge}
                    </span>
                  )}
                </h3>

                <p className="m-0 mt-1 text-[11px] text-[#94a3b8] flex items-center gap-2">
                  <span className="flex items-center gap-0.5 font-mono text-slate-300">
                    <Clock className="w-3 h-3 text-[#a3e635]" />
                    {ride.etaMinutes} min {t.eta}
                  </span>
                  <span>•</span>
                  <span>★ {ride.rating}</span>
                  {isONDC && (
                    <>
                      <span>•</span>
                      <span className="text-[#a3e635] font-semibold">{t.zeroCommission}</span>
                    </>
                  )}
                </p>
              </div>

              {/* Price & Action Button (Right) */}
              <div className="ride-price-action text-right flex flex-col items-end gap-1.5 shrink-0 pl-2">
                <div className="price text-base font-black text-white font-mono tracking-tight">
                  ₹{ride.calculatedFare}
                </div>

                {/* Primary Action Button */}
                {isONDC ? (
                  <button
                    id={`btn-book-direct-${ride.id}`}
                    onClick={() => onBookDirectONDC(ride)}
                    className="book-btn flex items-center gap-1"
                  >
                    <span>{t.bookDirectly}</span>
                    <ArrowRight className="w-3 h-3 stroke-[2.5]" />
                  </button>
                ) : (
                  <button
                    id={`btn-open-webview-${ride.id}`}
                    onClick={() => onOpenWebView(ride.provider, ride)}
                    className="webview-btn flex items-center gap-1"
                  >
                    <span>{t.webView}</span>
                    <ExternalLink className="w-3 h-3" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
