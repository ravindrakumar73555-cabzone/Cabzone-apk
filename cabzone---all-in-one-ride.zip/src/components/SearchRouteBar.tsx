import React, { useState, useRef, useEffect } from 'react';
import { 
  MapPin, 
  ArrowUpDown, 
  Search, 
  Navigation, 
  Plane, 
  Briefcase, 
  Train, 
  Sparkles, 
  Building2,
  Loader2,
  CheckCircle2
} from 'lucide-react';
import { LocationItem, LanguageCode } from '../types';
import { INDIAN_LANDMARKS_DATABASE } from '../data/mockData';
import { TRANSLATIONS } from '../data/translations';

interface SearchRouteBarProps {
  pickup: LocationItem;
  drop: LocationItem;
  language: LanguageCode;
  onPickupChange: (loc: LocationItem) => void;
  onDropChange: (loc: LocationItem) => void;
  onSwapLocations: () => void;
  distanceKm: number;
  durationMinutes: number;
  onTriggerGps: () => void;
  isLocatingGps: boolean;
  gpsActive: boolean;
}

export const SearchRouteBar: React.FC<SearchRouteBarProps> = ({
  pickup,
  drop,
  language,
  onPickupChange,
  onDropChange,
  onSwapLocations,
  distanceKm,
  durationMinutes,
  onTriggerGps,
  isLocatingGps,
  gpsActive,
}) => {
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  const [pickupInput, setPickupInput] = useState<string>(pickup.name);
  const [dropInput, setDropInput] = useState<string>(drop.name);
  const [activeInput, setActiveInput] = useState<'pickup' | 'drop' | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  // Sync inputs with location changes
  useEffect(() => {
    setPickupInput(pickup.name);
  }, [pickup.name]);

  useEffect(() => {
    setDropInput(drop.name);
  }, [drop.name]);

  // Handle outside click to close dropdown reliably
  useEffect(() => {
    const handleOutsideClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setActiveInput(null);
      }
    };
    document.addEventListener('mousedown', handleOutsideClick);
    return () => document.removeEventListener('mousedown', handleOutsideClick);
  }, []);

  // Filter recommendations based on current user typed query
  const currentQuery = (activeInput === 'pickup' ? pickupInput : dropInput).trim().toLowerCase();

  const filteredSuggestions = INDIAN_LANDMARKS_DATABASE.filter((loc) => {
    if (!currentQuery) return true;
    return (
      loc.name.toLowerCase().includes(currentQuery) ||
      loc.address.toLowerCase().includes(currentQuery)
    );
  });

  // Top quick landmarks requested by user
  const quickLandmarks = [
    { label: 'Delhi T3', loc: INDIAN_LANDMARKS_DATABASE[1], icon: Plane },
    { label: 'Connaught Pl.', loc: INDIAN_LANDMARKS_DATABASE[2], icon: Building2 },
    { label: 'Mumbai BKC', loc: INDIAN_LANDMARKS_DATABASE[3], icon: Briefcase },
    { label: 'Ludhiana Focal Pt', loc: INDIAN_LANDMARKS_DATABASE[4], icon: Building2 },
    { label: 'HSR Bengaluru', loc: INDIAN_LANDMARKS_DATABASE[0], icon: Sparkles },
    { label: 'Howrah Kolkata', loc: INDIAN_LANDMARKS_DATABASE[10], icon: Train },
  ];

  const handleSelectPickup = (loc: LocationItem) => {
    onPickupChange(loc);
    setPickupInput(loc.name);
    setActiveInput(null);
  };

  const handleSelectDrop = (loc: LocationItem) => {
    onDropChange(loc);
    setDropInput(loc.name);
    setActiveInput(null);
  };

  return (
    <div 
      ref={containerRef}
      id="cabzone-search-section" 
      className="search-section bg-[#0f172a] p-3.5 border-b border-[#334155] shadow-lg relative z-30"
    >
      {/* Route Inputs Container */}
      <div className="relative flex flex-col gap-2.5">
        
        {/* PICKUP LOCATION INPUT */}
        <div className="input-group relative">
          <div className="flex items-center justify-between mb-1 px-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#a3e635] flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-[#a3e635]" />
              {t.pickupLabel}
            </span>

            {/* REAL GPS GEOLOCATION TRIGGER BUTTON */}
            <button
              id="btn-detect-gps"
              type="button"
              onClick={onTriggerGps}
              disabled={isLocatingGps}
              className={`text-[10px] font-semibold flex items-center gap-1 px-2 py-0.5 rounded-full border transition-all ${
                gpsActive
                  ? 'bg-[#a3e635]/20 text-[#a3e635] border-[#a3e635]/50'
                  : 'bg-[#1e293b] text-[#cbd5e1] border-[#475569] hover:border-[#a3e635] hover:text-[#a3e635]'
              }`}
              title="Detect real device GPS position"
            >
              {isLocatingGps ? (
                <>
                  <Loader2 className="w-3 h-3 text-[#a3e635] animate-spin" />
                  <span>{t.gpsLocating}</span>
                </>
              ) : gpsActive ? (
                <>
                  <CheckCircle2 className="w-3 h-3 text-[#a3e635]" />
                  <span>{t.gpsActive}</span>
                </>
              ) : (
                <>
                  <Navigation className="w-3 h-3 text-[#a3e635]" />
                  <span>{t.gpsLocate}</span>
                </>
              )}
            </button>
          </div>

          <div className="relative">
            <input
              id="input-pickup"
              type="text"
              value={pickupInput}
              onFocus={() => setActiveInput('pickup')}
              onChange={(e) => {
                setPickupInput(e.target.value);
                if (activeInput !== 'pickup') setActiveInput('pickup');
              }}
              placeholder={t.pickupPlaceholder}
              autoComplete="off"
              className="w-full pr-8 pl-3 py-2 bg-[#1e293b] border border-[#475569] focus:border-[#a3e635] focus:ring-1 focus:ring-[#a3e635] rounded-lg text-xs font-semibold text-white placeholder-[#94a3b8] outline-none transition-all shadow-inner"
            />
            {pickupInput && (
              <button
                type="button"
                onClick={() => {
                  setPickupInput('');
                  setActiveInput('pickup');
                }}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[#94a3b8] hover:text-white text-xs w-5 h-5 flex items-center justify-center rounded-full hover:bg-[#334155]"
                aria-label="Clear pickup"
              >
                ✕
              </button>
            )}
          </div>

          {/* Autocomplete suggestions dropdown for Pickup */}
          {activeInput === 'pickup' && (
            <div 
              id="pickup-autocomplete-dropdown"
              className="suggestions-box absolute top-full left-0 right-0 bg-[#1e293b] border border-[#475569] rounded-b-xl shadow-2xl max-h-56 overflow-y-auto z-40 block mt-1 divide-y divide-[#334155]"
            >
              <div className="px-3 py-1.5 bg-[#0f172a] text-[10px] font-bold text-[#94a3b8] uppercase tracking-wider flex justify-between items-center sticky top-0 z-10">
                <span>{t.popularIndianLocations}</span>
                <span className="text-[#a3e635] text-[10px]">{filteredSuggestions.length} found</span>
              </div>
              {filteredSuggestions.length === 0 ? (
                <div className="p-3 text-center text-xs text-[#94a3b8]">
                  No matching Indian landmark. Try typing 'Delhi', 'Ludhiana', 'Mumbai', or 'Airport'.
                </div>
              ) : (
                filteredSuggestions.map((loc) => (
                  <div
                    key={`pickup-${loc.id}`}
                    onMouseDown={(e) => {
                      e.preventDefault(); // Prevent input blur before click registers
                      handleSelectPickup(loc);
                    }}
                    className="suggestion-item p-2.5 hover:bg-[#334155] cursor-pointer flex items-start gap-2.5 text-xs transition-colors"
                  >
                    <MapPin className="w-3.5 h-3.5 text-[#a3e635] shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-white truncate">{loc.name}</div>
                      <div className="text-[10px] text-[#94a3b8] truncate">{loc.address}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* DROP DESTINATION INPUT */}
        <div className="input-group relative">
          <div className="flex items-center justify-between mb-1 px-1">
            <span className="text-[10px] font-bold uppercase tracking-wider text-[#ff4d6d] flex items-center gap-1">
              <span className="w-2 h-2 rounded-sm bg-[#ff4d6d]" />
              {t.dropLabel}
            </span>
            <span className="text-[10px] font-mono text-[#94a3b8]">
              {distanceKm.toFixed(1)} km • ~{durationMinutes} min
            </span>
          </div>

          <div className="relative">
            <input
              id="input-drop"
              type="text"
              value={dropInput}
              onFocus={() => setActiveInput('drop')}
              onChange={(e) => {
                setDropInput(e.target.value);
                if (activeInput !== 'drop') setActiveInput('drop');
              }}
              placeholder={t.dropPlaceholder}
              autoComplete="off"
              className="w-full pr-12 pl-3 py-2 bg-[#1e293b] border border-[#475569] focus:border-[#a3e635] focus:ring-1 focus:ring-[#a3e635] rounded-lg text-xs font-semibold text-white placeholder-[#94a3b8] outline-none transition-all shadow-inner"
            />
            
            {/* Clear Drop Button */}
            {dropInput && (
              <button
                type="button"
                onClick={() => {
                  setDropInput('');
                  setActiveInput('drop');
                }}
                className="absolute right-9 top-1/2 -translate-y-1/2 text-[#94a3b8] hover:text-white text-xs w-5 h-5 flex items-center justify-center rounded-full hover:bg-[#334155]"
                aria-label="Clear drop"
              >
                ✕
              </button>
            )}

            {/* Swap Button */}
            <button
              id="btn-swap-locations"
              type="button"
              onClick={onSwapLocations}
              title={t.swap}
              className="absolute right-1.5 top-1/2 -translate-y-1/2 w-7 h-7 rounded-md bg-[#0f172a] hover:bg-[#334155] text-[#a3e635] border border-[#334155] flex items-center justify-center transition-transform active:rotate-180 shadow"
            >
              <ArrowUpDown className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Autocomplete suggestions dropdown for Drop */}
          {activeInput === 'drop' && (
            <div 
              id="drop-autocomplete-dropdown"
              className="suggestions-box absolute top-full left-0 right-0 bg-[#1e293b] border border-[#475569] rounded-b-xl shadow-2xl max-h-56 overflow-y-auto z-40 block mt-1 divide-y divide-[#334155]"
            >
              <div className="px-3 py-1.5 bg-[#0f172a] text-[10px] font-bold text-[#94a3b8] uppercase tracking-wider flex justify-between items-center sticky top-0 z-10">
                <span>{t.popularIndianLocations}</span>
                <span className="text-[#a3e635] text-[10px]">{filteredSuggestions.length} found</span>
              </div>
              {filteredSuggestions.length === 0 ? (
                <div className="p-3 text-center text-xs text-[#94a3b8]">
                  No matching Indian landmark. Try typing 'Delhi', 'Ludhiana', 'Mumbai', or 'Airport'.
                </div>
              ) : (
                filteredSuggestions.map((loc) => (
                  <div
                    key={`drop-${loc.id}`}
                    onMouseDown={(e) => {
                      e.preventDefault(); // Prevent input blur before click registers
                      handleSelectDrop(loc);
                    }}
                    className="suggestion-item p-2.5 hover:bg-[#334155] cursor-pointer flex items-start gap-2.5 text-xs transition-colors"
                  >
                    <MapPin className="w-3.5 h-3.5 text-[#ff4d6d] shrink-0 mt-0.5" />
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-white truncate">{loc.name}</div>
                      <div className="text-[10px] text-[#94a3b8] truncate">{loc.address}</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>

      {/* Quick Indian Landmark Hubs */}
      <div className="flex items-center gap-1.5 mt-2.5 overflow-x-auto no-scrollbar py-0.5">
        <span className="text-[9px] font-bold text-[#94a3b8] uppercase tracking-wider whitespace-nowrap">
          Quick:
        </span>
        {quickLandmarks.map((pill) => {
          const isSelected = drop.id === pill.loc.id;
          const Icon = pill.icon;
          return (
            <button
              key={pill.label}
              type="button"
              onClick={() => handleSelectDrop(pill.loc)}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[10px] font-medium whitespace-nowrap transition-all border ${
                isSelected
                  ? 'bg-[#a3e635] text-[#0b1120] border-[#a3e635] font-bold shadow-sm'
                  : 'bg-[#1e293b] text-[#cbd5e1] border-[#334155] hover:border-[#a3e635]/60 hover:text-white'
              }`}
            >
              <Icon className="w-2.5 h-2.5" />
              <span>{pill.label}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
};
