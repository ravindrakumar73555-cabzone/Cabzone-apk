import React, { useState, useEffect } from 'react';
import { 
  X, 
  RotateCw, 
  Lock, 
  Share2, 
  MoreVertical, 
  ExternalLink, 
  ShieldCheck, 
  ChevronLeft, 
  ChevronRight, 
  ArrowLeft,
  CheckCircle2,
  Clock,
  Car,
  CreditCard,
  Sliders,
  DollarSign
} from 'lucide-react';
import { LocationItem, RideOption, RideProvider } from '../types';

interface InAppWebViewProps {
  isOpen: boolean;
  onClose: () => void;
  provider: RideProvider;
  ride?: RideOption;
  pickup: LocationItem;
  drop: LocationItem;
  calculatedFare: number;
}

export const InAppWebView: React.FC<InAppWebViewProps> = ({
  isOpen,
  onClose,
  provider,
  ride,
  pickup,
  drop,
  calculatedFare,
}) => {
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [loadProgress, setLoadProgress] = useState<number>(15);
  const [activeTab, setActiveTab] = useState<'RIDE' | 'FARE_BREAKDOWN'>('RIDE');
  const [isBookedInWebview, setIsBookedInWebview] = useState<boolean>(false);
  const [biddingPrice, setBiddingPrice] = useState<number>(calculatedFare || 190);
  const [incomingBids, setIncomingBids] = useState<Array<{ id: string; driver: string; price: number; car: string; rating: number }>>([]);
  const [isSearchingBids, setIsSearchingBids] = useState<boolean>(false);

  // Sync bidding price if fare changes
  useEffect(() => {
    if (calculatedFare) {
      setBiddingPrice(calculatedFare);
    }
  }, [calculatedFare]);

  // Simulate WebView initial loading
  useEffect(() => {
    if (isOpen) {
      setIsLoading(true);
      setLoadProgress(20);
      setIsBookedInWebview(false);
      setIsSearchingBids(false);
      setIncomingBids([]);

      const timer1 = setTimeout(() => setLoadProgress(65), 250);
      const timer2 = setTimeout(() => setLoadProgress(100), 600);
      const timer3 = setTimeout(() => setIsLoading(false), 750);

      return () => {
        clearTimeout(timer1);
        clearTimeout(timer2);
        clearTimeout(timer3);
      };
    }
  }, [isOpen, provider]);

  if (!isOpen) return null;

  const getProviderConfig = () => {
    switch (provider) {
      case 'UBER':
        return {
          name: 'Uber',
          domain: 'm.uber.com',
          fullUrl: `https://m.uber.com/looking-for-ride?pickup=${encodeURIComponent(pickup.name)}&drop=${encodeURIComponent(drop.name)}`,
          themeColor: '#000000',
          accentColor: '#ffffff',
          brandText: 'Uber',
        };
      case 'OLA':
        return {
          name: 'Ola Cabs',
          domain: 'book.olacabs.com',
          fullUrl: `https://book.olacabs.com/?origin=${encodeURIComponent(pickup.name)}&destination=${encodeURIComponent(drop.name)}`,
          themeColor: '#0b1d0e',
          accentColor: '#00e676',
          brandText: 'OLA',
        };
      case 'INDRIVE':
        return {
          name: 'inDrive',
          domain: 'indrive.com',
          fullUrl: `https://indrive.com/rides?from=${encodeURIComponent(pickup.name)}&to=${encodeURIComponent(drop.name)}`,
          themeColor: '#041829',
          accentColor: '#00e5ff',
          brandText: 'inDrive',
        };
      default:
        return {
          name: 'Web Booking',
          domain: 'm.web-booking.com',
          fullUrl: 'https://m.web-booking.com',
          themeColor: '#070b14',
          accentColor: '#10ef70',
          brandText: 'RIDE',
        };
    }
  };

  const config = getProviderConfig();

  const handleRefresh = () => {
    setIsLoading(true);
    setLoadProgress(30);
    setTimeout(() => setLoadProgress(80), 200);
    setTimeout(() => {
      setLoadProgress(100);
      setIsLoading(false);
    }, 450);
  };

  const handleStartInDriveBidding = () => {
    setIsSearchingBids(true);
    setTimeout(() => {
      setIncomingBids([
        { id: 'b1', driver: 'Kiran R.', price: biddingPrice, car: 'Maruti WagonR', rating: 4.8 },
        { id: 'b2', driver: 'Vikram S.', price: biddingPrice + 20, car: 'Hyundai i10', rating: 4.9 },
      ]);
      setIsSearchingBids(false);
    }, 1200);
  };

  return (
    <div 
      id="in-app-webview-container"
      className="webview-overlay fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex flex-col justify-end sm:justify-center animate-in slide-in-from-bottom-5 duration-300"
      style={{ display: 'flex' }}
    >
      {/* Mobile Browser Window Container */}
      <div className="relative w-full max-w-md mx-auto h-[92vh] max-h-[820px] bg-[#0c101c] rounded-t-3xl sm:rounded-3xl border border-white/20 shadow-2xl flex flex-col overflow-hidden">
        
        {/* Android In-App Chrome Custom Tab Toolbar matching .webview-header */}
        <div className="webview-header bg-[#0f172a] border-b border-[#334155] px-3 py-2.5 flex items-center justify-between shrink-0 shadow-md">
          {/* Close WebView Button matching .close-webview */}
          <button
            id="btn-close-webview"
            onClick={onClose}
            aria-label="Close WebView and return to CABZONE"
            className="close-webview w-8 h-8 rounded-full bg-white/10 text-white hover:bg-white/20 flex items-center justify-center active:scale-95 transition-all"
          >
            <X className="w-4 h-4" />
          </button>

          {/* Security SSL & URL pill matching .browser-bar */}
          <div className="browser-bar flex-1 mx-2 px-3 py-1.5 bg-[#1e293b] border border-[#475569] rounded-full flex items-center justify-between min-w-0">
            <div className="flex items-center gap-1.5 min-w-0">
              <Lock className="w-3 h-3 text-[#a3e635] shrink-0" />
              <span className="text-[11px] font-mono text-slate-300 truncate">
                {config.domain}
              </span>
            </div>
            <span className="text-[9px] bg-white/10 text-slate-400 px-1 rounded uppercase font-semibold shrink-0 ml-1">
              WebView
            </span>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-1">
            <button
              id="btn-refresh-webview"
              onClick={handleRefresh}
              aria-label="Reload WebView"
              className="w-7 h-7 rounded-full text-slate-300 hover:text-white flex items-center justify-center"
            >
              <RotateCw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin text-[#a3e635]' : ''}`} />
            </button>
            <button
              onClick={() => {
                alert(`Simulated: In the native app, this would open ${config.fullUrl} in external browser.`);
              }}
              className="w-7 h-7 rounded-full text-slate-300 hover:text-white flex items-center justify-center"
            >
              <MoreVertical className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Loading Progress Bar */}
        <div className="h-0.5 w-full bg-transparent">
          {isLoading && (
            <div 
              className="h-full bg-[#a3e635] transition-all duration-300"
              style={{ width: `${loadProgress}%` }}
            />
          )}
        </div>

        {/* Brand Header inside WebView */}
        <div className="px-4 py-2 border-b border-white/10 flex items-center justify-between text-xs" style={{ backgroundColor: config.themeColor }}>
          <div className="flex items-center gap-2">
            <span className="font-black text-sm text-white tracking-tight">
              {config.brandText}
            </span>
            <span className="text-[10px] text-slate-400">Mobile Web Portal</span>
          </div>
          <div className="text-[10px] text-slate-400">
            Powered via CABZONE In-App
          </div>
        </div>

        {/* Embedded Provider Web Interface Content matching .webview-body */}
        <div className="webview-body flex-1 overflow-y-auto p-4 bg-[#0a0f1d] text-white">
          {provider === 'UBER' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div>
                  <h3 className="text-base font-bold">Request a Ride</h3>
                  <p className="text-xs text-slate-400">Uber Web Instant Booking</p>
                </div>
                <div className="px-2.5 py-1 bg-white text-black font-black text-xs rounded-lg">
                  UBER
                </div>
              </div>

              {/* Pre-filled Route Overview */}
              <div className="bg-[#12192b] p-3 rounded-xl border border-white/10 space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-white" />
                  <span className="text-xs text-slate-300 truncate"><strong>Pickup:</strong> {pickup.name}</span>
                </div>
                <div className="border-l border-dashed border-slate-600 ml-1 h-3" />
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 bg-black border border-white" />
                  <span className="text-xs text-slate-300 truncate"><strong>Drop:</strong> {drop.name}</span>
                </div>
              </div>

              {/* Uber Vehicle Options inside Webview */}
              <div className="space-y-2">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Available Products</span>
                
                <div className="p-3 rounded-xl bg-white/10 border-2 border-white flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="text-2xl">🚗</div>
                    <div>
                      <div className="text-xs font-bold">Uber Go</div>
                      <div className="text-[10px] text-slate-400">Affordable compact rides • 4 min</div>
                    </div>
                  </div>
                  <div className="text-right font-mono font-bold text-sm">
                    ₹{calculatedFare || 245}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between opacity-80">
                  <div className="flex items-center gap-2.5">
                    <div className="text-2xl">🚕</div>
                    <div>
                      <div className="text-xs font-bold">Uber Premier</div>
                      <div className="text-[10px] text-slate-400">Premium comfortable sedans • 6 min</div>
                    </div>
                  </div>
                  <div className="text-right font-mono font-bold text-sm">
                    ₹{Math.round((calculatedFare || 245) * 1.3)}
                  </div>
                </div>
              </div>

              {/* Payment selector */}
              <div className="p-2.5 rounded-xl bg-[#12192b] border border-white/10 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-slate-300" />
                  <span>Uber Pay (Balance: ₹420)</span>
                </div>
                <span className="text-[11px] text-blue-400 font-medium">Change</span>
              </div>

              {/* Booking Button */}
              {!isBookedInWebview ? (
                <button
                  id="btn-confirm-uber-webview"
                  onClick={() => setIsBookedInWebview(true)}
                  className="w-full py-3 bg-white text-black hover:bg-slate-200 font-bold rounded-xl text-sm shadow-lg transition-all active:scale-95"
                >
                  Confirm Uber Go
                </button>
              ) : (
                <div className="p-3.5 bg-emerald-950/60 border border-emerald-500/50 rounded-xl text-center space-y-1">
                  <CheckCircle2 className="w-6 h-6 text-emerald-400 mx-auto" />
                  <div className="text-sm font-bold text-emerald-300">Ride Confirmed on Uber Web!</div>
                  <p className="text-xs text-slate-300">Driver dispatched to {pickup.name}.</p>
                </div>
              )}
            </div>
          )}

          {provider === 'OLA' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div>
                  <h3 className="text-base font-bold text-[#76ff03]">Ola Cabs Web</h3>
                  <p className="text-xs text-slate-400">Book cabs, autos & outstation</p>
                </div>
                <div className="px-2.5 py-1 bg-[#183315] border border-[#76ff03] text-[#76ff03] font-black text-xs rounded-lg">
                  OLA
                </div>
              </div>

              {/* Route Summary */}
              <div className="bg-[#0f1f14] p-3 rounded-xl border border-[#76ff03]/30 space-y-2">
                <div className="text-xs text-slate-300">
                  <strong className="text-[#76ff03]">Pickup:</strong> {pickup.name}
                </div>
                <div className="text-xs text-slate-300">
                  <strong className="text-amber-400">Drop:</strong> {drop.name}
                </div>
              </div>

              {/* Categories */}
              <div className="space-y-2">
                <div className="p-3 rounded-xl bg-[#142817] border-2 border-[#76ff03] flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="text-2xl">🚗</div>
                    <div>
                      <div className="text-xs font-bold text-white">Ola Mini</div>
                      <div className="text-[10px] text-slate-400">Regular AC hatchbacks • 3 min</div>
                    </div>
                  </div>
                  <div className="text-right font-mono font-bold text-sm text-[#76ff03]">
                    ₹{calculatedFare || 230}
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-white/5 border border-white/10 flex items-center justify-between opacity-80">
                  <div className="flex items-center gap-2.5">
                    <div className="text-2xl">🛺</div>
                    <div>
                      <div className="text-xs font-bold text-white">Ola Auto</div>
                      <div className="text-[10px] text-slate-400">Fast auto rickshaw • 2 min</div>
                    </div>
                  </div>
                  <div className="text-right font-mono font-bold text-sm text-white">
                    ₹{Math.round((calculatedFare || 230) * 0.65)}
                  </div>
                </div>
              </div>

              {/* Action */}
              {!isBookedInWebview ? (
                <button
                  id="btn-confirm-ola-webview"
                  onClick={() => setIsBookedInWebview(true)}
                  className="w-full py-3 bg-[#76ff03] hover:bg-[#64dd17] text-black font-black rounded-xl text-sm shadow-lg transition-all active:scale-95"
                >
                  Ride Now (Ola Mini)
                </button>
              ) : (
                <div className="p-3.5 bg-emerald-950/60 border border-[#76ff03] rounded-xl text-center space-y-1">
                  <CheckCircle2 className="w-6 h-6 text-[#76ff03] mx-auto" />
                  <div className="text-sm font-bold text-[#76ff03]">Ola Ride Booked!</div>
                  <p className="text-xs text-slate-300">Searching for fastest driver match.</p>
                </div>
              )}
            </div>
          )}

          {provider === 'INDRIVE' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div>
                  <h3 className="text-base font-bold text-[#00e5ff]">inDrive City</h3>
                  <p className="text-xs text-slate-400">Set your own price, negotiate with drivers</p>
                </div>
                <div className="px-2 py-0.5 bg-[#032034] text-[#00e5ff] font-bold text-xs rounded border border-[#00e5ff]">
                  inDrive
                </div>
              </div>

              {/* Bidding Fare Controller */}
              <div className="bg-[#0b1c2b] p-3.5 rounded-xl border border-[#00e5ff]/30 text-center space-y-2">
                <span className="text-[11px] text-slate-400 uppercase font-semibold">Your Proposed Offer</span>
                <div className="text-3xl font-black text-[#00e5ff] font-mono">
                  ₹{biddingPrice}
                </div>
                <div className="flex items-center justify-center gap-2 pt-1">
                  <button
                    onClick={() => setBiddingPrice((p) => Math.max(80, p - 10))}
                    className="px-3 py-1 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold"
                  >
                    - ₹10
                  </button>
                  <button
                    onClick={() => setBiddingPrice((p) => p + 10)}
                    className="px-3 py-1 bg-white/10 hover:bg-white/20 rounded-lg text-xs font-bold"
                  >
                    + ₹10
                  </button>
                </div>
                <p className="text-[10px] text-slate-400">Recommended starting bid: ₹{calculatedFare || 190}</p>
              </div>

              {!isSearchingBids && incomingBids.length === 0 && (
                <button
                  id="btn-find-indrive-driver"
                  onClick={handleStartInDriveBidding}
                  className="w-full py-3 bg-[#00e5ff] hover:bg-[#00b0ff] text-black font-black rounded-xl text-sm shadow-lg transition-all active:scale-95"
                >
                  Find a Driver at ₹{biddingPrice}
                </button>
              )}

              {isSearchingBids && (
                <div className="py-6 text-center space-y-2">
                  <div className="w-8 h-8 border-2 border-[#00e5ff] border-t-transparent rounded-full animate-spin mx-auto" />
                  <div className="text-xs text-[#00e5ff] font-semibold">Showing your offer to nearby drivers...</div>
                </div>
              )}

              {incomingBids.length > 0 && (
                <div className="space-y-2 animate-in fade-in">
                  <span className="text-xs font-bold text-slate-300">Driver Counter Offers:</span>
                  {incomingBids.map((bid) => (
                    <div key={bid.id} className="p-3 bg-[#112436] rounded-xl border border-white/15 flex items-center justify-between">
                      <div>
                        <div className="text-xs font-bold text-white">{bid.driver} ({bid.rating}★)</div>
                        <div className="text-[10px] text-slate-400">{bid.car}</div>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-black font-mono text-[#00e5ff]">₹{bid.price}</span>
                        <button
                          onClick={() => {
                            alert(`Accepted offer from ${bid.driver} for ₹${bid.price}!`);
                            setIsBookedInWebview(true);
                          }}
                          className="px-2.5 py-1 bg-[#00e5ff] text-black font-bold text-xs rounded-lg hover:bg-cyan-300"
                        >
                          Accept
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Bottom Browser Bar with Return to CABZONE Option */}
        <div className="bg-[#101726] border-t border-white/10 px-4 py-2.5 flex items-center justify-between shrink-0">
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 text-xs text-slate-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
            <span>Back to CABZONE</span>
          </button>

          <button
            onClick={onClose}
            className="text-[11px] font-bold text-[#10ef70] bg-[#10ef70]/15 hover:bg-[#10ef70]/25 px-2.5 py-1 rounded-full border border-[#10ef70]/30 flex items-center gap-1"
          >
            Compare ONDC Direct (-₹{Math.round(calculatedFare * 0.25 || 50)})
          </button>
        </div>
      </div>
    </div>
  );
};
