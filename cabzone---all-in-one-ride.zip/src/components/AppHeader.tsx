import React from 'react';
import { 
  Smartphone, 
  Monitor, 
  Info,
  Globe
} from 'lucide-react';
import { LanguageCode, SUPPORTED_LANGUAGES } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface AppHeaderProps {
  language: LanguageCode;
  onLanguageChange: (lang: LanguageCode) => void;
  isMobileFrame: boolean;
  onToggleFrame: () => void;
  onOpenInfo: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  language,
  onLanguageChange,
  isMobileFrame,
  onToggleFrame,
  onOpenInfo,
}) => {
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;

  return (
    <header className="bg-[#0f172a] border-b border-[#334155] px-3.5 py-3 flex items-center justify-between shrink-0 select-none z-30">
      {/* Brand Logo & Tagline (Matching User Template) */}
      <div className="logo-area flex items-center gap-2.5">
        <div className="w-8 h-8 rounded-lg bg-[#a3e635] text-[#0b1120] font-black text-sm flex items-center justify-center shadow-[0_0_12px_rgba(163,230,53,0.3)]">
          CZ
        </div>
        <div>
          <h1 id="txt-title" className="m-0 text-lg font-black tracking-wide text-[#a3e635] leading-tight">
            {t.title}
          </h1>
          <p id="txt-tagline" className="m-0 text-[9px] text-[#94a3b8] font-bold uppercase tracking-wider">
            {t.tagline}
          </p>
        </div>
      </div>

      {/* Right Controls: Language Selector + Device Toggle + Info */}
      <div className="flex items-center gap-2">
        {/* Language Selector Dropdown from User Template */}
        <div className="relative flex items-center">
          <select
            id="select-language"
            value={language}
            onChange={(e) => onLanguageChange(e.target.value as LanguageCode)}
            className="lang-select"
            aria-label="Select Language"
          >
            {SUPPORTED_LANGUAGES.map((lang) => (
              <option key={lang.code} value={lang.code}>
                {lang.nativeName} ({lang.label})
              </option>
            ))}
          </select>
        </div>

        {/* Frame Toggle (Handy for desktop testing) */}
        <button
          onClick={onToggleFrame}
          title={isMobileFrame ? "Switch to Full View" : "Switch to Android Phone Frame"}
          className="hidden md:flex items-center gap-1 px-2 py-1 bg-[#1e293b] hover:bg-[#334155] border border-[#334155] rounded-md text-[11px] text-[#94a3b8] hover:text-white transition-colors"
        >
          {isMobileFrame ? (
            <>
              <Monitor className="w-3 h-3 text-[#a3e635]" />
              <span>Full</span>
            </>
          ) : (
            <>
              <Smartphone className="w-3 h-3 text-[#a3e635]" />
              <span>Frame</span>
            </>
          )}
        </button>

        {/* Info Guide */}
        <button
          onClick={onOpenInfo}
          title="App Info"
          className="w-7 h-7 rounded-md bg-[#1e293b] border border-[#334155] text-[#94a3b8] hover:text-[#a3e635] hover:border-[#a3e635] flex items-center justify-center transition-colors text-xs"
        >
          <Info className="w-3.5 h-3.5" />
        </button>
      </div>
    </header>
  );
};
