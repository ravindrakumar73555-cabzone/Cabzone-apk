import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Signal } from 'lucide-react';

export const AndroidStatusBar: React.FC = () => {
  const [time, setTime] = useState<string>('09:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      const hours = now.getHours().toString().padStart(2, '0');
      const mins = now.getMinutes().toString().padStart(2, '0');
      setTime(`${hours}:${mins}`);
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="w-full bg-[#050811] px-4 py-1 flex items-center justify-between text-[11px] font-semibold text-slate-300 select-none shrink-0 z-40">
      <span>{time}</span>
      <div className="flex items-center gap-1.5">
        <span className="text-[10px] text-[#10ef70] font-bold">5G</span>
        <Signal className="w-3 h-3 text-slate-300" />
        <Wifi className="w-3 h-3 text-slate-300" />
        <div className="flex items-center gap-0.5">
          <span className="text-[10px]">96%</span>
          <div className="w-4 h-2 border border-slate-300 rounded-[2px] p-0.5 flex items-center">
            <div className="w-full h-full bg-[#10ef70] rounded-[1px]" />
          </div>
        </div>
      </div>
    </div>
  );
};

export const AndroidNavBar: React.FC = () => {
  return (
    <div className="w-full bg-[#050811] py-2 flex items-center justify-center shrink-0 z-40">
      {/* Android Gesture Pill */}
      <div className="w-28 h-1 bg-white/30 rounded-full" />
    </div>
  );
};
