import React, { useState, useEffect, useRef } from 'react';
import { 
  Navigation, 
  Car, 
  Compass, 
  Plus, 
  Minus, 
  Radio, 
  MapPin, 
  CheckCircle2, 
  ShieldCheck,
  Zap,
  Info
} from 'lucide-react';
import { LocationItem, MovingDriver, RideOption, LanguageCode } from '../types';
import { TRANSLATIONS } from '../data/translations';

interface LiveMapProps {
  pickup: LocationItem;
  drop: LocationItem;
  drivers: MovingDriver[];
  language: LanguageCode;
  onSelectDriverDirect?: (driver: MovingDriver) => void;
  onBookDirectONDC?: (ride: RideOption) => void;
}

export const LiveMap: React.FC<LiveMapProps> = ({
  pickup,
  drop,
  drivers,
  language,
  onSelectDriverDirect,
}) => {
  const t = TRANSLATIONS[language] || TRANSLATIONS.en;
  const [selectedDriver, setSelectedDriver] = useState<MovingDriver | null>(null);
  const [zoomLevel, setZoomLevel] = useState<number>(1);
  const [radarActive, setRadarActive] = useState<boolean>(true);
  const [activeDriverCount, setActiveDriverCount] = useState<number>(14);
  const [mapPan, setMapPan] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState<boolean>(false);

  // Periodic driver count variance to feel alive
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveDriverCount((prev) => {
        const delta = Math.random() > 0.5 ? 1 : -1;
        const next = prev + delta;
        return next >= 9 && next <= 18 ? next : prev;
      });
    }, 4500);
    return () => clearInterval(interval);
  }, []);

  const handleRecenter = () => {
    setMapPan({ x: 0, y: 0 });
    setZoomLevel(1);
    setSelectedDriver(null);
  };

  // Generate curved bezier path between pickup and drop
  const pX = pickup.lat;
  const pY = pickup.lng;
  const dX = drop.lat;
  const dY = drop.lng;

  // Intermediate midpoint with slight curvature for realistic road trajectory
  const midX = (pX + dX) / 2 + (dY - pY) * 0.18;
  const midY = (pY + dY) / 2 - (dX - pX) * 0.18;
  const routePath = `M ${pX * 8} ${pY * 6} Q ${midX * 8} ${midY * 6} ${dX * 8} ${dY * 6}`;

  return (
    <div 
      id="cabzone-live-map"
      className="relative w-full h-full min-h-[220px] max-h-[380px] bg-[#070b14] overflow-hidden select-none border-b border-white/10"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Background Vector Map Grid & Road Canvas */}
      <div 
        className="absolute inset-0 transition-transform duration-300 ease-out pointer-events-none"
        style={{
          transform: `scale(${zoomLevel}) translate(${mapPan.x}px, ${mapPan.y}px)`,
          transformOrigin: `${pickup.lat}% ${pickup.lng}%`,
        }}
      >
        <svg className="w-full h-full" viewBox="0 0 800 600" preserveAspectRatio="none">
          <defs>
            <radialGradient id="cityGlow" cx="50%" cy="50%" r="60%">
              <stop offset="0%" stopColor="#0d1829" stopOpacity="1" />
              <stop offset="60%" stopColor="#080e1a" stopOpacity="1" />
              <stop offset="100%" stopColor="#050811" stopOpacity="1" />
            </radialGradient>

            <linearGradient id="routeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#10ef70" />
              <stop offset="50%" stopColor="#00e5ff" />
              <stop offset="100%" stopColor="#ff4d6d" />
            </linearGradient>

            <pattern id="cityGrid" width="40" height="40" patternUnits="userSpaceOnUse">
              <path d="M 40 0 L 0 0 0 40" fill="none" stroke="rgba(255, 255, 255, 0.04)" strokeWidth="1" />
            </pattern>

            <pattern id="smallGrid" width="10" height="10" patternUnits="userSpaceOnUse">
              <path d="M 10 0 L 0 0 0 10" fill="none" stroke="rgba(255, 255, 255, 0.015)" strokeWidth="0.5" />
            </pattern>

            {/* Pulsing Beacon Glow */}
            <filter id="glow" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="3" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* Canvas Background Fill */}
          <rect width="800" height="600" fill="url(#cityGlow)" />
          <rect width="800" height="600" fill="url(#smallGrid)" />
          <rect width="800" height="600" fill="url(#cityGrid)" />

          {/* Urban Green Spaces / Lake simulation */}
          <path 
            d="M 600,80 Q 660,120 640,220 T 560,260 T 530,140 Z" 
            fill="rgba(16, 239, 112, 0.03)" 
            stroke="rgba(16, 239, 112, 0.12)" 
            strokeWidth="1" 
          />
          <path 
            d="M 60,340 Q 140,360 160,450 T 90,520 T 40,400 Z" 
            fill="rgba(0, 180, 255, 0.04)" 
            stroke="rgba(0, 180, 255, 0.15)" 
            strokeWidth="1" 
          />

          {/* Major Highway / Express Arteries */}
          <g stroke="rgba(255, 255, 255, 0.09)" strokeWidth="6" fill="none" strokeLinecap="round">
            <path d="M 0,160 Q 280,190 520,130 T 800,210" />
            <path d="M 120,0 Q 210,250 360,380 T 680,600" />
            <path d="M 0,420 Q 320,440 540,390 T 800,470" />
          </g>

          {/* Secondary Arterial Avenues */}
          <g stroke="rgba(255, 255, 255, 0.04)" strokeWidth="3" fill="none">
            <path d="M 40,0 L 40,600" />
            <path d="M 220,0 L 220,600" />
            <path d="M 450,0 L 450,600" />
            <path d="M 650,0 L 650,600" />
            <path d="M 0,80 L 800,80" />
            <path d="M 0,280 L 800,280" />
            <path d="M 0,510 L 800,510" />
          </g>

          {/* Active Navigation Route Polyline */}
          <path 
            d={routePath} 
            fill="none" 
            stroke="rgba(16, 239, 112, 0.2)" 
            strokeWidth="8" 
            strokeLinecap="round"
          />
          <path 
            d={routePath} 
            fill="none" 
            stroke="url(#routeGradient)" 
            strokeWidth="4" 
            strokeLinecap="round"
            strokeDasharray="8 6"
            className="animate-pulse"
            filter="url(#glow)"
          />

          {/* Pickup Radar Ripples */}
          <circle 
            cx={pX * 8} 
            cy={pY * 6} 
            r="28" 
            fill="none" 
            stroke="#10ef70" 
            strokeWidth="1.5" 
            opacity="0.6"
            className="car-pulse"
          />
          <circle 
            cx={pX * 8} 
            cy={pY * 6} 
            r="48" 
            fill="rgba(16, 239, 112, 0.04)" 
            stroke="#10ef70" 
            strokeWidth="1" 
            strokeDasharray="4 4"
            opacity="0.4"
          />
        </svg>
      </div>

      {/* Radar Sweep Effect (toggleable) */}
      {radarActive && (
        <div 
          className="absolute pointer-events-none rounded-full radar-sweep"
          style={{
            top: `calc(${pickup.lng}% - 140px)`,
            left: `calc(${pickup.lat}% - 140px)`,
            width: '280px',
            height: '280px',
            background: 'conic-gradient(from 0deg at 50% 50%, rgba(16, 239, 112, 0.18) 0deg, rgba(16, 239, 112, 0) 65deg, transparent 360deg)',
            maskImage: 'radial-gradient(circle, black 30%, transparent 70%)',
            WebkitMaskImage: 'radial-gradient(circle, black 30%, transparent 70%)',
          }}
        />
      )}

      {/* Interactive Driver Markers (ONDC Moving Dots) */}
      {drivers.map((drv) => {
        const isSelected = selectedDriver?.id === drv.id;
        return (
          <button
            key={drv.id}
            id={`ondc-driver-${drv.id}`}
            onClick={() => {
              setSelectedDriver(drv);
              if (onSelectDriverDirect) onSelectDriverDirect(drv);
            }}
            aria-label={`Driver ${drv.name}, ${drv.type}`}
            className="absolute z-20 group transform -translate-x-1/2 -translate-y-1/2 transition-transform duration-200 active:scale-95 focus:outline-none"
            style={{
              left: `${drv.lat}%`,
              top: `${drv.lng}%`,
            }}
          >
            {/* Pulsing Aura */}
            <span className="absolute -inset-1 rounded-full bg-[#10ef70]/30 animate-ping opacity-75" />
            
            {/* Driver Badge Marker */}
            <div className={`relative flex items-center justify-center w-7 h-7 rounded-full shadow-lg transition-all ${
              isSelected 
                ? 'bg-[#10ef70] text-[#070b14] ring-4 ring-[#10ef70]/40 scale-125' 
                : 'bg-[#0f1d14] border border-[#10ef70]/80 text-[#10ef70] hover:scale-110 hover:border-[#10ef70]'
            }`}>
              {drv.type === 'AUTO' ? (
                <span className="text-[11px] font-black tracking-tighter">🛺</span>
              ) : (
                <Car className="w-3.5 h-3.5" />
              )}
            </div>

            {/* Mini ETA tag over driver */}
            <div className="absolute -bottom-3.5 left-1/2 -translate-x-1/2 px-1 py-0.2 bg-black/90 border border-[#10ef70]/40 rounded text-[8px] font-mono text-[#10ef70] whitespace-nowrap">
              ONDC
            </div>
          </button>
        );
      })}

      {/* Pickup Location Marker (User Pin) */}
      <div 
        className="absolute z-20 -translate-x-1/2 -translate-y-full pointer-events-none"
        style={{ left: `${pickup.lat}%`, top: `${pickup.lng}%` }}
      >
        <div className="flex flex-col items-center">
          <div className="px-2 py-0.5 bg-[#0a1526]/90 border border-[#10ef70] rounded-full text-[10px] font-semibold text-[#10ef70] shadow-md flex items-center gap-1 mb-1 backdrop-blur-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-[#10ef70] animate-ping" />
            Pickup
          </div>
          <div className="relative">
            <div className="w-6 h-6 rounded-full bg-[#10ef70] text-[#070b14] flex items-center justify-center font-bold text-xs shadow-lg shadow-[#10ef70]/40 border-2 border-white">
              <MapPin className="w-3.5 h-3.5 fill-current" />
            </div>
          </div>
        </div>
      </div>

      {/* Drop Location Marker (Destination Flag) */}
      <div 
        className="absolute z-20 -translate-x-1/2 -translate-y-full pointer-events-none"
        style={{ left: `${drop.lat}%`, top: `${drop.lng}%` }}
      >
        <div className="flex flex-col items-center">
          <div className="px-2 py-0.5 bg-[#1f0d14]/90 border border-[#ff4d6d] rounded-full text-[10px] font-semibold text-[#ff4d6d] shadow-md flex items-center gap-1 mb-1 backdrop-blur-sm">
            <span className="w-1.5 h-1.5 rounded-full bg-[#ff4d6d]" />
            Drop
          </div>
          <div className="w-6 h-6 rounded-full bg-[#ff4d6d] text-white flex items-center justify-center font-bold text-xs shadow-lg shadow-[#ff4d6d]/40 border-2 border-white">
            🏁
          </div>
        </div>
      </div>

      {/* Top Map HUD Floating Controls */}
      <div className="absolute top-2.5 left-3 right-3 flex items-center justify-between pointer-events-auto z-30">
        {/* Live ONDC Drivers Indicator with User id and class */}
        <div id="txt-drivers-online" className="status-badge flex items-center gap-1.5 shadow-md">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#a3e635] opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-[#a3e635]"></span>
          </span>
          <span className="font-semibold text-[11px] text-white tracking-wide">
            🟢 <strong className="text-[#a3e635]">{activeDriverCount}</strong> {t.driversOnline}
          </span>
        </div>

        {/* Map Utility Controls */}
        <div className="flex items-center gap-1 bg-[#070e1c]/90 border border-white/10 rounded-full p-0.5 backdrop-blur-md shadow-md">
          <button
            id="btn-toggle-radar"
            onClick={() => setRadarActive(!radarActive)}
            title={radarActive ? "Radar Active" : "Radar Off"}
            className={`w-7 h-7 rounded-full flex items-center justify-center transition-colors ${
              radarActive ? 'text-[#10ef70] bg-[#10ef70]/10' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Radio className="w-3.5 h-3.5" />
          </button>
          
          <button
            id="btn-recenter-map"
            onClick={handleRecenter}
            title="Recenter Map"
            className="w-7 h-7 rounded-full flex items-center justify-center text-slate-300 hover:text-[#10ef70] transition-colors"
          >
            <Navigation className="w-3.5 h-3.5" />
          </button>

          <button
            id="btn-zoom-in"
            onClick={() => setZoomLevel((z) => Math.min(1.4, z + 0.1))}
            title="Zoom In"
            className="w-7 h-7 rounded-full flex items-center justify-center text-slate-300 hover:text-white transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
          </button>

          <button
            id="btn-zoom-out"
            onClick={() => setZoomLevel((z) => Math.max(0.8, z - 0.1))}
            title="Zoom Out"
            className="w-7 h-7 rounded-full flex items-center justify-center text-slate-300 hover:text-white transition-colors"
          >
            <Minus className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Selected Driver Popup Drawer (if user taps on any moving ONDC dot) */}
      {selectedDriver && (
        <div 
          id="driver-quick-info-popup"
          className="absolute bottom-2 left-3 right-3 z-30 bg-[#0a1222]/95 border border-[#10ef70]/60 rounded-xl p-2.5 backdrop-blur-lg shadow-xl animate-in fade-in slide-in-from-bottom-2 duration-200"
        >
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-full bg-[#10ef70]/20 border border-[#10ef70] flex items-center justify-center text-sm">
                {selectedDriver.type === 'AUTO' ? '🛺' : '🚕'}
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <span className="text-xs font-bold text-white">{selectedDriver.name}</span>
                  <span className="px-1 py-0.2 text-[9px] bg-[#10ef70]/20 text-[#10ef70] rounded font-semibold flex items-center gap-0.5">
                    <ShieldCheck className="w-2.5 h-2.5" /> ONDC Verified
                  </span>
                </div>
                <div className="text-[10px] text-slate-400">
                  {selectedDriver.vehicle} • <span className="text-slate-300 font-mono">{selectedDriver.plate}</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                id="btn-close-driver-popup"
                onClick={() => setSelectedDriver(null)}
                className="text-xs px-2 py-1 text-slate-400 hover:text-white rounded"
              >
                ✕
              </button>
              <button
                id="btn-request-selected-driver"
                onClick={() => {
                  if (onSelectDriverDirect) onSelectDriverDirect(selectedDriver);
                }}
                className="text-[11px] font-bold px-2.5 py-1 bg-[#10ef70] hover:bg-[#00e676] text-[#070b14] rounded-lg shadow-md transition-all active:scale-95"
              >
                Direct Connect
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
