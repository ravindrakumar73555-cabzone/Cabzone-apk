import React, { useState, useEffect } from 'react';
import { 
  X, 
  ShieldCheck, 
  Phone, 
  MessageSquare, 
  CheckCircle2, 
  QrCode, 
  Banknote, 
  Share2, 
  Navigation,
  Clock,
  Car,
  AlertCircle
} from 'lucide-react';
import { BookingState, LocationItem, RideOption } from '../types';

interface ONDCBookingModalProps {
  booking: BookingState;
  pickup: LocationItem;
  drop: LocationItem;
  onClose: () => void;
  onCancelRide: () => void;
}

export const ONDCBookingModal: React.FC<ONDCBookingModalProps> = ({
  booking,
  pickup,
  drop,
  onClose,
  onCancelRide,
}) => {
  const [phase, setPhase] = useState<'broadcasting' | 'assigned'>('broadcasting');
  const [paymentMode, setPaymentMode] = useState<'UPI' | 'CASH'>('UPI');
  const [showQr, setShowQr] = useState<boolean>(false);

  useEffect(() => {
    if (booking.isOpen) {
      setPhase('broadcasting');
      setShowQr(false);
      // Simulate rapid direct ONDC driver matchmaking in 1.4 seconds
      const timer = setTimeout(() => {
        setPhase('assigned');
      }, 1400);
      return () => clearTimeout(timer);
    }
  }, [booking.isOpen]);

  if (!booking.isOpen || !booking.ride) return null;

  const ride = booking.ride;
  const driver = booking.driver || {
    name: 'Suresh V. Gowda',
    phone: '+91 98451 22819',
    vehicle: ride.vehicleType === 'AUTO' ? 'Bajaj RE Auto' : 'Maruti Suzuki Dzire',
    plate: 'KA-05-MN-2841',
    rating: 4.92,
    trips: 4180,
    etaMinutes: ride.etaMinutes || 3,
    otp: '5821',
  };

  return (
    <div 
      id="ondc-booking-modal"
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col justify-end sm:justify-center p-3 animate-in fade-in duration-200"
    >
      <div className="relative w-full max-w-md mx-auto bg-[#0a1120] border-2 border-[#10ef70] rounded-3xl shadow-2xl p-4 sm:p-5 flex flex-col overflow-hidden">
        
        {/* Glow accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-48 h-1 bg-[#10ef70] rounded-b-full shadow-[0_0_20px_#10ef70]" />

        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-[#10ef70]/20 text-[#10ef70] flex items-center justify-center font-bold">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white tracking-wide flex items-center gap-1.5">
                ONDC DIRECT BOOKING
              </h3>
              <span className="text-[10px] text-[#10ef70] font-semibold">
                Open Network for Digital Commerce
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-white/10 text-slate-300 hover:text-white flex items-center justify-center text-xs"
          >
            ✕
          </button>
        </div>

        {/* Phase 1: Broadcasting to ONDC network */}
        {phase === 'broadcasting' ? (
          <div className="py-10 flex flex-col items-center justify-center text-center space-y-4">
            <div className="relative w-20 h-20">
              <div className="absolute inset-0 rounded-full bg-[#10ef70]/20 animate-ping" />
              <div className="absolute inset-2 rounded-full border-2 border-[#10ef70] border-t-transparent animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center text-2xl">
                {ride.vehicleType === 'AUTO' ? '🛺' : '🚕'}
              </div>
            </div>

            <div>
              <h4 className="text-base font-bold text-white">Broadcasting Request Directly</h4>
              <p className="text-xs text-slate-400 mt-1 max-w-xs">
                Notifying nearby independent drivers within 2.5 km with zero platform cuts.
              </p>
            </div>

            <div className="px-3 py-1.5 rounded-full bg-[#10ef70]/15 border border-[#10ef70]/40 text-[#10ef70] text-xs font-mono font-semibold">
              Locking direct fare: ₹{ride.calculatedFare}
            </div>
          </div>
        ) : (
          /* Phase 2: Driver Assigned and Confirmed */
          <div className="py-3 space-y-3.5">
            {/* Success Status Banner */}
            <div className="p-2.5 rounded-2xl bg-gradient-to-r from-[#10ef70]/20 via-[#10ef70]/10 to-transparent border border-[#10ef70]/40 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-[#10ef70]" />
                <div>
                  <div className="text-xs font-bold text-white">Driver Assigned Directly!</div>
                  <div className="text-[10px] text-slate-300">Arriving in approx <strong className="text-[#10ef70]">{driver.etaMinutes} minutes</strong></div>
                </div>
              </div>
              <div className="text-right">
                <span className="text-[9px] uppercase font-bold text-slate-400 block">START OTP</span>
                <span className="text-base font-mono font-black text-[#10ef70] tracking-widest bg-black/40 px-2 py-0.5 rounded border border-[#10ef70]/40">
                  {driver.otp}
                </span>
              </div>
            </div>

            {/* Driver Profile Card */}
            <div className="bg-[#121c30] p-3.5 rounded-2xl border border-white/10 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-[#10ef70]/20 border border-[#10ef70] flex items-center justify-center text-xl font-bold text-[#10ef70]">
                    {driver.name.charAt(0)}
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-1.5">
                      {driver.name}
                      <span className="text-[10px] font-semibold text-amber-300 bg-amber-400/20 px-1 rounded">
                        ★ {driver.rating}
                      </span>
                    </h4>
                    <p className="text-xs text-slate-300">{driver.vehicle}</p>
                    <p className="text-[11px] font-mono text-[#10ef70] font-bold">{driver.plate}</p>
                  </div>
                </div>

                {/* Call and Message buttons */}
                <div className="flex items-center gap-2">
                  <a
                    href={`tel:${driver.phone}`}
                    onClick={(e) => {
                      e.preventDefault();
                      alert(`Calling driver ${driver.name} at ${driver.phone}`);
                    }}
                    className="w-9 h-9 rounded-full bg-[#10ef70] text-[#070b14] flex items-center justify-center shadow-lg hover:scale-105 active:scale-95 transition-transform"
                    title="Call Driver"
                  >
                    <Phone className="w-4 h-4 fill-current" />
                  </a>
                  <button
                    onClick={() => {
                      alert(`Direct Chat opened with ${driver.name}: "I am waiting near the main gate."`);
                    }}
                    className="w-9 h-9 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-white/20 active:scale-95 transition-transform"
                    title="Chat"
                  >
                    <MessageSquare className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Trip details */}
              <div className="pt-2 border-t border-white/10 text-xs space-y-1 text-slate-300">
                <div className="flex justify-between">
                  <span className="text-slate-400">Pickup:</span>
                  <span className="font-semibold text-white truncate max-w-[200px]">{pickup.name}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Drop:</span>
                  <span className="font-semibold text-white truncate max-w-[200px]">{drop.name}</span>
                </div>
                <div className="flex justify-between pt-1 border-t border-white/10 font-bold text-sm">
                  <span className="text-white">Direct Total Fare:</span>
                  <span className="text-[#10ef70] font-mono text-base">₹{ride.calculatedFare}</span>
                </div>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-1.5">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">Pay Directly to Driver</span>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => {
                    setPaymentMode('UPI');
                    setShowQr(true);
                  }}
                  className={`p-2.5 rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold transition-all ${
                    paymentMode === 'UPI'
                      ? 'bg-[#10ef70]/20 border-[#10ef70] text-white shadow-md'
                      : 'bg-[#121a2c] border-white/10 text-slate-400'
                  }`}
                >
                  <QrCode className="w-4 h-4 text-[#10ef70]" />
                  <span>UPI QR Code</span>
                </button>
                <button
                  onClick={() => {
                    setPaymentMode('CASH');
                    setShowQr(false);
                  }}
                  className={`p-2.5 rounded-xl border flex items-center justify-center gap-2 text-xs font-semibold transition-all ${
                    paymentMode === 'CASH'
                      ? 'bg-[#10ef70]/20 border-[#10ef70] text-white shadow-md'
                      : 'bg-[#121a2c] border-white/10 text-slate-400'
                  }`}
                >
                  <Banknote className="w-4 h-4 text-[#10ef70]" />
                  <span>Cash on Arrival</span>
                </button>
              </div>
            </div>

            {/* Simulated QR Code if UPI chosen */}
            {showQr && (
              <div className="p-3 bg-white text-black rounded-2xl text-center space-y-2 animate-in zoom-in-95 duration-150">
                <div className="text-xs font-bold">Scan with Google Pay / PhonePe / Paytm</div>
                <div className="w-32 h-32 mx-auto bg-slate-100 border-2 border-slate-300 p-2 rounded-xl flex items-center justify-center">
                  <div className="font-mono text-center text-[10px] text-slate-600">
                    <QrCode className="w-24 h-24 mx-auto text-slate-900" />
                    <div>upi://pay?pa=driver@upi</div>
                  </div>
                </div>
                <div className="text-[11px] font-bold text-slate-700">Amount: ₹{ride.calculatedFare} (100% to Driver)</div>
              </div>
            )}

            {/* Bottom Actions */}
            <div className="flex items-center gap-2 pt-2">
              <button
                onClick={onCancelRide}
                className="flex-1 py-2.5 bg-rose-500/15 hover:bg-rose-500/25 text-rose-300 border border-rose-500/30 rounded-xl text-xs font-semibold transition-colors"
              >
                Cancel Ride
              </button>
              <button
                onClick={onClose}
                className="flex-1 py-2.5 bg-[#10ef70] hover:bg-[#00e676] text-[#070b14] font-black rounded-xl text-xs shadow-lg transition-all active:scale-95"
              >
                Track on Map
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
