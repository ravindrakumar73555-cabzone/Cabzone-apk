export type RideProvider = 'ONDC' | 'UBER' | 'OLA' | 'INDRIVE';
export type VehicleType = 'AUTO' | 'BIKE' | 'MINI' | 'SEDAN' | 'XL';
export type LanguageCode = 'en' | 'hi' | 'pb' | 'bn' | 'ta' | 'te' | 'mr' | 'gu' | 'kn' | 'ml';

export interface LanguageOption {
  code: LanguageCode;
  label: string;
  nativeName: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'en', label: 'English', nativeName: 'English' },
  { code: 'hi', label: 'Hindi', nativeName: 'हिन्दी' },
  { code: 'pb', label: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ' },
  { code: 'bn', label: 'Bengali', nativeName: 'বাংলা' },
  { code: 'ta', label: 'Tamil', nativeName: 'தமிழ்' },
  { code: 'te', label: 'Telugu', nativeName: 'తెలుగు' },
  { code: 'mr', label: 'Marathi', nativeName: 'मराठी' },
  { code: 'gu', label: 'Gujarati', nativeName: 'ગુજરાતી' },
  { code: 'kn', label: 'Kannada', nativeName: 'ಕನ್ನಡ' },
  { code: 'ml', label: 'Malayalam', nativeName: 'മലയാളം' },
];

export interface LocationItem {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  tag?: 'Home' | 'Work' | 'Airport' | 'Metro' | 'TechPark' | 'Mall' | 'Popular';
}

export interface RideOption {
  id: string;
  provider: RideProvider;
  providerName: string;
  name: string;
  vehicleType: VehicleType;
  baseFare: number;
  perKmRate: number;
  calculatedFare: number;
  etaMinutes: number;
  rating: number;
  capacity: number;
  badge?: string;
  badgeType?: 'lime' | 'amber' | 'blue' | 'purple';
  isDirectONDC: boolean;
  surgeMultiplier: number;
  description: string;
  highlights: string[];
}

export interface MovingDriver {
  id: string;
  name: string;
  vehicle: string;
  plate: string;
  rating: number;
  lat: number; // percentage in map 0 - 100
  lng: number; // percentage in map 0 - 100
  speedX: number;
  speedY: number;
  type: 'AUTO' | 'CAB';
  phone: string;
  tripsCount: number;
}

export interface WebViewConfig {
  isOpen: boolean;
  provider: RideProvider;
  url: string;
  title: string;
  selectedRide?: RideOption;
}

export interface BookingState {
  isOpen: boolean;
  ride?: RideOption;
  status: 'searching' | 'confirmed' | 'arriving' | 'in_trip' | 'completed';
  driver?: {
    name: string;
    phone: string;
    vehicle: string;
    plate: string;
    rating: number;
    trips: number;
    etaMinutes: number;
    otp: string;
  };
}
