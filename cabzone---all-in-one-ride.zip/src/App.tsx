import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { AppHeader } from './components/AppHeader';
import { LiveMap } from './components/LiveMap';
import { SearchRouteBar } from './components/SearchRouteBar';
import { RideList } from './components/RideList';
import { InAppWebView } from './components/InAppWebView';
import { ONDCBookingModal } from './components/ONDCBookingModal';
import { AndroidStatusBar, AndroidNavBar } from './components/AndroidBars';
import { InfoModal } from './components/InfoModal';
import { 
  INDIAN_LANDMARKS_DATABASE, 
  INITIAL_DRIVERS, 
  calculateRideOptions 
} from './data/mockData';
import { 
  LocationItem, 
  MovingDriver, 
  RideOption, 
  RideProvider,
  BookingState,
  LanguageCode
} from './types';

export default function App() {
  // Localization: English, Hindi, Punjabi, Bengali, Tamil, Telugu, Marathi, Gujarati, Kannada, Malayalam
  const [language, setLanguage] = useState<LanguageCode>('en');

  // Navigation locations (Initialized with Delhi Airport T3 and Connaught Place, or GPS on mount)
  const [pickup, setPickup] = useState<LocationItem>(INDIAN_LANDMARKS_DATABASE[0]); // HSR Layout Bengaluru or real GPS
  const [drop, setDrop] = useState<LocationItem>(INDIAN_LANDMARKS_DATABASE[1]); // Delhi Airport T3

  // Real HTML5 Geolocation states
  const [isLocatingGps, setIsLocatingGps] = useState<boolean>(false);
  const [gpsActive, setGpsActive] = useState<boolean>(false);

  // Moving Drivers on map
  const [drivers, setDrivers] = useState<MovingDriver[]>(INITIAL_DRIVERS);

  // Filter category in rides list
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');

  // In-App WebView state for Uber, Ola, InDrive
  const [webView, setWebView] = useState<{
    isOpen: boolean;
    provider: RideProvider;
    selectedRide?: RideOption;
  }>({
    isOpen: false,
    provider: 'UBER',
  });

  // Direct ONDC Booking modal state
  const [bookingState, setBookingState] = useState<BookingState>({
    isOpen: false,
    status: 'searching',
  });

  // Prototype info guide modal
  const [isInfoOpen, setIsInfoOpen] = useState<boolean>(false);

  // Desktop Android Frame container toggle
  const [isMobileFrame, setIsMobileFrame] = useState<boolean>(true);

  // Function to execute real device GPS detection
  const fetchRealGpsLocation = useCallback(() => {
    if (!navigator.geolocation) {
      console.warn('Geolocation API is not supported by this browser.');
      return;
    }

    setIsLocatingGps(true);

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        let displayName = `GPS: ${latitude.toFixed(4)}° N, ${longitude.toFixed(4)}° E`;
        let detailedAddress = `Live Device GPS Fix (Lat: ${latitude.toFixed(5)}, Lon: ${longitude.toFixed(5)})`;

        // Attempt reverse geocoding via OpenStreetMap Nominatim with a fast timeout
        try {
          const controller = new AbortController();
          const timeoutId = setTimeout(() => controller.abort(), 2500);
          
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?lat=${latitude}&lon=${longitude}&format=json&zoom=16`,
            { 
              signal: controller.signal,
              headers: { 'Accept-Language': 'en' }
            }
          );
          clearTimeout(timeoutId);

          if (response.ok) {
            const data = await response.json();
            const suburb = data.address?.suburb || data.address?.neighbourhood || data.address?.road || data.address?.city_district;
            const city = data.address?.city || data.address?.town || data.address?.state_district || data.address?.state;
            
            if (suburb || city) {
              displayName = suburb ? `${suburb}, ${city || ''}` : city;
            }
            if (data.display_name) {
              detailedAddress = data.display_name.split(',').slice(0, 3).join(', ');
            }
          }
        } catch (err) {
          // If reverse geocoding is blocked or times out, the formatted GPS coordinates are preserved
          console.log('Reverse geocoding fallback to direct coordinates:', err);
        }

        const realGpsLocation: LocationItem = {
          id: 'real-gps-detected',
          name: displayName,
          address: detailedAddress,
          lat: 48,
          lng: 42,
          tag: 'Home',
        };

        setPickup(realGpsLocation);
        setGpsActive(true);
        setIsLocatingGps(false);
      },
      (error) => {
        console.warn('HTML5 Geolocation error or permission denied:', error.message);
        setIsLocatingGps(false);
        setGpsActive(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 8000,
        maximumAge: 30000,
      }
    );
  }, []);

  // Automatically trigger real HTML5 device GPS on app load
  useEffect(() => {
    fetchRealGpsLocation();
  }, [fetchRealGpsLocation]);

  // Continuous physics loop for moving ONDC driver dots
  useEffect(() => {
    const interval = setInterval(() => {
      setDrivers((prevDrivers) =>
        prevDrivers.map((drv) => {
          let nextLat = drv.lat + drv.speedX;
          let nextLng = drv.lng + drv.speedY;
          let speedX = drv.speedX;
          let speedY = drv.speedY;

          // Boundary turnarounds for natural city driving
          if (nextLat > 80 || nextLat < 20) {
            speedX = -speedX;
            nextLat = Math.max(20, Math.min(80, nextLat));
          }
          if (nextLng > 75 || nextLng < 25) {
            speedY = -speedY;
            nextLng = Math.max(25, Math.min(75, nextLng));
          }

          // Random slight turn
          if (Math.random() < 0.05) {
            speedX += (Math.random() - 0.5) * 0.04;
            speedY += (Math.random() - 0.5) * 0.04;
          }

          return {
            ...drv,
            lat: nextLat,
            lng: nextLng,
            speedX,
            speedY,
          };
        })
      );
    }, 120);

    return () => clearInterval(interval);
  }, []);

  // Calculate distance between pickup and drop based on landmark coordinates
  const distanceKm = useMemo(() => {
    const dLat = drop.lat - pickup.lat;
    const dLng = drop.lng - pickup.lng;
    const euclidean = Math.sqrt(dLat * dLat + dLng * dLng);
    // Scale to realistic city & intercity transit distances (between 3.5 km and 45 km)
    const km = Math.max(3.2, Math.min(48, euclidean * 0.52 + 2.4));
    return Number(km.toFixed(1));
  }, [pickup, drop]);

  // Estimated drive duration
  const durationMinutes = useMemo(() => {
    return Math.round(distanceKm * 2.2 + 5);
  }, [distanceKm]);

  // Recalculate options for all providers based on current route
  // calculateRideOptions ALWAYS guarantees sorting from absolute lowest fare to highest fare!
  const rideOptions = useMemo(() => {
    return calculateRideOptions(distanceKm);
  }, [distanceKm]);

  // Swap pickup & drop handler
  const handleSwapLocations = useCallback(() => {
    setPickup(drop);
    setDrop(pickup);
  }, [pickup, drop]);

  // Trigger In-App WebView for Uber, Ola, or InDrive
  const handleOpenWebView = useCallback((provider: RideProvider, ride: RideOption) => {
    setWebView({
      isOpen: true,
      provider,
      selectedRide: ride,
    });
  }, []);

  // Trigger simulated Direct ONDC booking
  const handleBookDirectONDC = useCallback((ride: RideOption) => {
    setBookingState({
      isOpen: true,
      ride,
      status: 'searching',
      driver: {
        name: 'Raju Mohan',
        phone: '+91 99160 84720',
        vehicle: ride.vehicleType === 'AUTO' ? 'Bajaj RE Auto' : 'White Maruti Dzire',
        plate: 'KA-05-MN-2841',
        rating: 4.89,
        trips: 4520,
        etaMinutes: ride.etaMinutes || 3,
        otp: '4821',
      },
    });
  }, []);

  // Connect directly from map dot
  const handleSelectDriverDirect = useCallback((driver: MovingDriver) => {
    const matchingRide = rideOptions.find(
      (r) => r.isDirectONDC && (driver.type === 'AUTO' ? r.vehicleType === 'AUTO' : r.vehicleType !== 'AUTO')
    ) || rideOptions[0];

    setBookingState({
      isOpen: true,
      ride: matchingRide,
      status: 'confirmed',
      driver: {
        name: driver.name,
        phone: driver.phone,
        vehicle: driver.vehicle,
        plate: driver.plate,
        rating: driver.rating,
        trips: driver.tripsCount,
        etaMinutes: 2,
        otp: '7294',
      },
    });
  }, [rideOptions]);

  return (
    <div className="w-full h-screen bg-[#060a12] flex items-center justify-center p-0 sm:p-4 md:p-6 overflow-hidden">
      
      {/* Outer Shell: Mobile Frame on Desktop or Edge-to-Edge on Mobile */}
      <div 
        id="cabzone-mobile-app-root"
        className={`phone-container w-full h-full flex flex-col bg-[#0b1120] text-slate-100 overflow-hidden relative shadow-2xl transition-all duration-300 ${
          isMobileFrame 
            ? 'sm:max-w-[440px] sm:max-h-[920px] sm:rounded-[40px] sm:border-[6px] sm:border-[#1e293b] sm:ring-1 sm:ring-white/20' 
            : 'max-w-none max-h-none rounded-none border-none'
        }`}
      >
        {/* Notch / Punch-hole simulation on mobile frame */}
        {isMobileFrame && (
          <div className="hidden sm:block absolute top-2 left-1/2 -translate-x-1/2 w-3.5 h-3.5 bg-black rounded-full z-50 ring-1 ring-white/10 pointer-events-none" />
        )}

        {/* Android Status Bar */}
        <AndroidStatusBar />

        {/* App Header (Brand, 10-Language Selector & Tagline: CABZONE - ALL-IN-ONE RIDE) */}
        <AppHeader 
          language={language}
          onLanguageChange={setLanguage}
          isMobileFrame={isMobileFrame}
          onToggleFrame={() => setIsMobileFrame(!isMobileFrame)}
          onOpenInfo={() => setIsInfoOpen(true)}
        />

        {/* Main Body View: Top 40% Live Map & Bottom 60% Search & Rides */}
        <div className="flex-1 flex flex-col overflow-hidden relative">
          
          {/* Top 40%: Simulated Live Map with moving ONDC driver dots */}
          <div className="map-section h-[36%] min-h-[185px] max-h-[310px] relative shrink-0">
            <LiveMap 
              pickup={pickup}
              drop={drop}
              drivers={drivers}
              language={language}
              onSelectDriverDirect={handleSelectDriverDirect}
            />
          </div>

          {/* Middle: Real GPS & 25-Landmark Autocomplete Search Bar */}
          <SearchRouteBar 
            pickup={pickup}
            drop={drop}
            language={language}
            onPickupChange={setPickup}
            onDropChange={setDrop}
            onSwapLocations={handleSwapLocations}
            distanceKm={distanceKm}
            durationMinutes={durationMinutes}
            onTriggerGps={fetchRealGpsLocation}
            isLocatingGps={isLocatingGps}
            gpsActive={gpsActive}
          />

          {/* Bottom: Clean scrollable list sorted from Lowest to Highest Fare */}
          <RideList 
            rides={rideOptions}
            language={language}
            onBookDirectONDC={handleBookDirectONDC}
            onOpenWebView={handleOpenWebView}
            selectedCategory={selectedCategory}
            onCategoryChange={setSelectedCategory}
          />
        </div>

        {/* Android Virtual Navigation Bar */}
        <AndroidNavBar onHomeClick={() => setSelectedCategory('ALL')} />

        {/* In-App WebView Overlay for Uber, Ola, InDrive */}
        <InAppWebView
          isOpen={webView.isOpen}
          provider={webView.provider}
          pickup={pickup}
          drop={drop}
          selectedRide={webView.selectedRide}
          onClose={() => setWebView((prev) => ({ ...prev, isOpen: false }))}
        />

        {/* Direct ONDC Booking Modal */}
        <ONDCBookingModal
          booking={bookingState}
          pickup={pickup}
          drop={drop}
          onClose={() => setBookingState({ isOpen: false, status: 'searching' })}
          onCancelRide={() => setBookingState({ isOpen: false, status: 'searching' })}
        />

        {/* Architecture & Info Modal */}
        <InfoModal
          isOpen={isInfoOpen}
          onClose={() => setIsInfoOpen(false)}
        />
      </div>
    </div>
  );
}
